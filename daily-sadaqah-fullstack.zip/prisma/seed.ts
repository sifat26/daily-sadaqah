// ============================================================================
// Daily Sadaqah — Controlled Sample Data Seed Script (prisma/seed.ts)
// SAFETY GUARD:
// 1. Refuses to run if NODE_ENV === "production" unless ALLOW_SAMPLE_SEED_IN_PROD="true".
// 2. Requires explicit `--confirm-seed` CLI flag.
// 3. Uses strictly fictional sample data labeled clearly as [নমুনা তথ্য].
// ============================================================================


export const INITIAL_NINE_PROJECTS = [
  {
    id: 'proj_medical',
    name: 'চিকিৎসা সহায়তা',
    slug: 'medical-assistance',
    category: 'MEDICAL' as const,
    description: 'দরিদ্র ও অসহায় রোগীদের ওষুধ, অপারেশন এবং জরুরি চিকিৎসা খরচে সহায়তা প্রদান।',
    imageUrl: '/assets/banner.jpg',
    targetAmountBdt: 150000,
    collectedBdt: 85000,
    status: 'ACTIVE' as const,
  },
  {
    id: 'proj_food',
    name: 'খাদ্য সহায়তা',
    slug: 'food-assistance',
    category: 'FOOD' as const,
    description: 'অসচ্ছল ও দিনমজুর পরিবারের মাঝে চাল, ডাল, তেলসহ নিত্যপ্রয়োজনীয় খাদ্যসামগ্রী বিতরণ।',
    imageUrl: '/assets/banner.jpg',
    targetAmountBdt: 100000,
    collectedBdt: 62000,
    status: 'ACTIVE' as const,
  },
  {
    id: 'proj_water',
    name: 'বিশুদ্ধ পানি',
    slug: 'clean-water',
    category: 'CLEAN_WATER' as const,
    description: 'প্রত্যন্ত ও সুবিধাবঞ্চিত অঞ্চলে টিউবওয়েল স্থাপন ও নিরাপদ খাবার পানির ব্যবস্থা করা।',
    imageUrl: '/assets/banner.jpg',
    targetAmountBdt: 120000,
    collectedBdt: 95000,
    status: 'ACTIVE' as const,
  },
  {
    id: 'proj_orphan',
    name: 'এতিম ও শিশু সহায়তা',
    slug: 'orphan-and-child-support',
    category: 'ORPHAN_CHILD' as const,
    description: 'এতিম ও অসহায় শিশুদের খাবার, পোশাক ও নিরাপদ বেড়ে ওঠার মাসিক সহায়তা তহবিল।',
    imageUrl: '/assets/banner.jpg',
    targetAmountBdt: 130000,
    collectedBdt: 74000,
    status: 'ACTIVE' as const,
  },
  {
    id: 'proj_education',
    name: 'শিক্ষা সহায়তা',
    slug: 'education-support',
    category: 'EDUCATION' as const,
    description: 'দরিদ্র মেধাবী শিক্ষার্থীদের বই-খাতা, স্কুলের বেতন এবং শিক্ষাবৃত্তি প্রদান।',
    imageUrl: '/assets/banner.jpg',
    targetAmountBdt: 90000,
    collectedBdt: 48000,
    status: 'ACTIVE' as const,
  },
  {
    id: 'proj_housing',
    name: 'ঘর মেরামত',
    slug: 'home-repair',
    category: 'HOUSING' as const,
    description: 'ঝড় বা বন্যায় ক্ষতিগ্রস্ত অসহায় পরিবারের ভাঙা ঘর মেরামত ও টিনের চালা প্রদান।',
    imageUrl: '/assets/banner.jpg',
    targetAmountBdt: 110000,
    collectedBdt: 55000,
    status: 'ACTIVE' as const,
  },
  {
    id: 'proj_emergency',
    name: 'জরুরি সহায়তা',
    slug: 'emergency-relief',
    category: 'EMERGENCY' as const,
    description: 'বন্যা, শৈত্যপ্রবাহ বা যেকোনো আকস্মিক দুর্যোগে ক্ষতিগ্রস্ত মানুষের পাশে তাৎক্ষণিক ত্রাণ সহায়তা।',
    imageUrl: '/assets/banner.jpg',
    targetAmountBdt: 160000,
    collectedBdt: 110000,
    status: 'ACTIVE' as const,
  },
  {
    id: 'proj_ramadan',
    name: 'ইফতার ও রমজান',
    slug: 'iftar-and-ramadan',
    category: 'RAMADAN_IFTAR' as const,
    description: 'পবিত্র রমজান মাসে রোজাদার ও দরিদ্র পরিবারের মাঝে ইফতার ও সাহরি সামগ্রী বিতরণ।',
    imageUrl: '/assets/banner.jpg',
    targetAmountBdt: 100000,
    collectedBdt: 68000,
    status: 'ACTIVE' as const,
  },
  {
    id: 'proj_general',
    name: 'সাধারণ সাদাকা',
    slug: 'general-sadaqah',
    category: 'GENERAL_SADAQAH' as const,
    description: 'প্রতিদিনের ছোট ছোট দান যা প্রয়োজন অনুযায়ী সবচেয়ে জরুরি কল্যাণমূলক কাজে ব্যয় করা হয়।',
    imageUrl: '/assets/banner.jpg',
    targetAmountBdt: 150000,
    collectedBdt: 92000,
    status: 'ACTIVE' as const,
  },
];

async function main() {
  if (process.env.NODE_ENV === 'production' && process.env.ALLOW_SAMPLE_SEED_IN_PROD !== 'true') {
    console.error('ABORT: Refusing to seed fictional sample financial records in production.');
    process.exit(1);
  }
  if (!process.argv.includes('--confirm-seed')) {
    console.error('ABORT: Pass `--confirm-seed` explicitly to run the sample seed script.');
    process.exit(1);
  }

  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const { PrismaClient } = require('@prisma/client');
  const prisma = new PrismaClient();
  try {
    console.log('Seeding roles and 9 initial Daily Sadaqah projects...');
    for (const roleName of ['USER', 'ADMIN', 'MODERATOR'] as const) {
      await prisma.role.upsert({
        where: { name: roleName },
        update: {},
        create: { name: roleName, description: `${roleName} role` },
      });
    }

    for (const p of INITIAL_NINE_PROJECTS) {
      await prisma.donationProject.upsert({
        where: { slug: p.slug },
        update: {
          name: p.name,
          description: p.description,
          category: p.category,
          targetAmountBdt: p.targetAmountBdt,
          status: p.status,
        },
        create: {
          id: p.id,
          name: p.name,
          slug: p.slug,
          description: p.description,
          category: p.category,
          imageUrl: p.imageUrl,
          targetAmountBdt: p.targetAmountBdt,
          collectedBdt: 0,
          status: p.status,
        },
      });
    }
    console.log('Seed completed successfully.');
  } finally {
    await prisma.$disconnect();
  }
}

if (require.main === module) {
  main().catch((err) => {
    console.error(err);
    process.exit(1);
  });
}
